
const express = require('express');
const Stripe = require('stripe');
const router = express.Router();

const stripe = new Stripe(process.env.STRIPE_SECRET_KEY);

router.post('/', async (req, res) => {
  const session = await stripe.checkout.sessions.create({
    payment_method_types: ['card'],
    line_items: [{
      price_data: {
        currency: 'eur',
        product_data: { name: 'BTC Chat AL Zugang' },
        unit_amount: 900,
      },
      quantity: 1,
    }],
    mode: 'payment',
    success_url: 'https://sabjanukeraj.github.io/Btc_Chat_AL/success.html',
    cancel_url: 'https://sabjanukeraj.github.io/Btc_Chat_AL/cancel.html',
  });
  res.json({ id: session.id });
});

module.exports = router;
