
const express = require('express');
const cors = require('cors');
const mongoose = require('mongoose');
require('dotenv').config();

const authRoutes = require('./routes/auth');
const gptRoutes = require('./routes/gpt');
const stripeRoutes = require('./routes/stripe');

const app = express();
app.use(cors());
app.use(express.json());

app.use('/api/auth', authRoutes);
app.use('/api/gpt', gptRoutes);
app.use('/api/checkout', stripeRoutes);

mongoose.connect(process.env.MONGO_URI)
  .then(() => console.log("✅ MongoDB verbunden"))
  .catch(err => console.error("❌ MongoDB Fehler:", err));

const PORT = process.env.PORT || 3001;
app.listen(PORT, () => console.log(`🚀 Backend läuft auf Port ${PORT}`));
