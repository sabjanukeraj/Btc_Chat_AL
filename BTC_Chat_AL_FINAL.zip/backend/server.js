
const express = require('express');
const cors = require('cors');
const app = express();
app.use(cors());
app.use(express.json());

app.post('/login', (req, res) => {
  res.json({ token: "jwt-token" });
});

app.post('/create-checkout-session', (req, res) => {
  res.json({ sessionId: "stripe-session" });
});

app.post('/gpt-analysis', (req, res) => {
  res.json({ answer: "Bitcoin wird laut aktuellen Trends im Jahr 2026..." });
});

app.listen(3001, () => console.log("Server läuft auf Port 3001"));
